<?php
/**
 * Template part for displaying the contact form section
 *
 * This file is now empty as its content has been moved to a modal.
 * The modal is loaded via popup-diagnostico.php in the footer.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package scs_consultoria
 */

?>